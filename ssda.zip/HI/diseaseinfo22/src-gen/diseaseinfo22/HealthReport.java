/**
 */
package diseaseinfo22;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Health Report</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link diseaseinfo22.HealthReport#getType <em>Type</em>}</li>
 *   <li>{@link diseaseinfo22.HealthReport#getNumber <em>Number</em>}</li>
 *   <li>{@link diseaseinfo22.HealthReport#getPatients <em>Patients</em>}</li>
 *   <li>{@link diseaseinfo22.HealthReport#getDoctors <em>Doctors</em>}</li>
 * </ul>
 *
 * @see diseaseinfo22.Diseaseinfo22Package#getHealthReport()
 * @model
 * @generated
 */
public interface HealthReport extends EObject {
	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see #setType(String)
	 * @see diseaseinfo22.Diseaseinfo22Package#getHealthReport_Type()
	 * @model
	 * @generated
	 */
	String getType();

	/**
	 * Sets the value of the '{@link diseaseinfo22.HealthReport#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see #getType()
	 * @generated
	 */
	void setType(String value);

	/**
	 * Returns the value of the '<em><b>Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Number</em>' attribute.
	 * @see #setNumber(int)
	 * @see diseaseinfo22.Diseaseinfo22Package#getHealthReport_Number()
	 * @model
	 * @generated
	 */
	int getNumber();

	/**
	 * Sets the value of the '{@link diseaseinfo22.HealthReport#getNumber <em>Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Number</em>' attribute.
	 * @see #getNumber()
	 * @generated
	 */
	void setNumber(int value);

	/**
	 * Returns the value of the '<em><b>Patients</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link diseaseinfo22.Patients#getHealthreport <em>Healthreport</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Patients</em>' reference.
	 * @see #setPatients(Patients)
	 * @see diseaseinfo22.Diseaseinfo22Package#getHealthReport_Patients()
	 * @see diseaseinfo22.Patients#getHealthreport
	 * @model opposite="healthreport" required="true"
	 * @generated
	 */
	Patients getPatients();

	/**
	 * Sets the value of the '{@link diseaseinfo22.HealthReport#getPatients <em>Patients</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Patients</em>' reference.
	 * @see #getPatients()
	 * @generated
	 */
	void setPatients(Patients value);

	/**
	 * Returns the value of the '<em><b>Doctors</b></em>' reference list.
	 * The list contents are of type {@link diseaseinfo22.Doctors}.
	 * It is bidirectional and its opposite is '{@link diseaseinfo22.Doctors#getHealthreport <em>Healthreport</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Doctors</em>' reference list.
	 * @see diseaseinfo22.Diseaseinfo22Package#getHealthReport_Doctors()
	 * @see diseaseinfo22.Doctors#getHealthreport
	 * @model opposite="healthreport" required="true"
	 * @generated
	 */
	EList<Doctors> getDoctors();

} // HealthReport
