/**
 */
package diseaseinfo22;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Symptoms</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link diseaseinfo22.Symptoms#getTypes <em>Types</em>}</li>
 *   <li>{@link diseaseinfo22.Symptoms#getNumberofsymp <em>Numberofsymp</em>}</li>
 *   <li>{@link diseaseinfo22.Symptoms#getDisease <em>Disease</em>}</li>
 *   <li>{@link diseaseinfo22.Symptoms#getPatients <em>Patients</em>}</li>
 * </ul>
 *
 * @see diseaseinfo22.Diseaseinfo22Package#getSymptoms()
 * @model
 * @generated
 */
public interface Symptoms extends EObject {
	/**
	 * Returns the value of the '<em><b>Types</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Types</em>' attribute.
	 * @see #setTypes(String)
	 * @see diseaseinfo22.Diseaseinfo22Package#getSymptoms_Types()
	 * @model
	 * @generated
	 */
	String getTypes();

	/**
	 * Sets the value of the '{@link diseaseinfo22.Symptoms#getTypes <em>Types</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Types</em>' attribute.
	 * @see #getTypes()
	 * @generated
	 */
	void setTypes(String value);

	/**
	 * Returns the value of the '<em><b>Numberofsymp</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Numberofsymp</em>' attribute.
	 * @see #setNumberofsymp(int)
	 * @see diseaseinfo22.Diseaseinfo22Package#getSymptoms_Numberofsymp()
	 * @model
	 * @generated
	 */
	int getNumberofsymp();

	/**
	 * Sets the value of the '{@link diseaseinfo22.Symptoms#getNumberofsymp <em>Numberofsymp</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Numberofsymp</em>' attribute.
	 * @see #getNumberofsymp()
	 * @generated
	 */
	void setNumberofsymp(int value);

	/**
	 * Returns the value of the '<em><b>Disease</b></em>' reference list.
	 * The list contents are of type {@link diseaseinfo22.Disease}.
	 * It is bidirectional and its opposite is '{@link diseaseinfo22.Disease#getSymptoms <em>Symptoms</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Disease</em>' reference list.
	 * @see diseaseinfo22.Diseaseinfo22Package#getSymptoms_Disease()
	 * @see diseaseinfo22.Disease#getSymptoms
	 * @model opposite="symptoms" required="true"
	 * @generated
	 */
	EList<Disease> getDisease();

	/**
	 * Returns the value of the '<em><b>Patients</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link diseaseinfo22.Patients#getSymptoms <em>Symptoms</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Patients</em>' reference.
	 * @see #setPatients(Patients)
	 * @see diseaseinfo22.Diseaseinfo22Package#getSymptoms_Patients()
	 * @see diseaseinfo22.Patients#getSymptoms
	 * @model opposite="symptoms" required="true"
	 * @generated
	 */
	Patients getPatients();

	/**
	 * Sets the value of the '{@link diseaseinfo22.Symptoms#getPatients <em>Patients</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Patients</em>' reference.
	 * @see #getPatients()
	 * @generated
	 */
	void setPatients(Patients value);

} // Symptoms
