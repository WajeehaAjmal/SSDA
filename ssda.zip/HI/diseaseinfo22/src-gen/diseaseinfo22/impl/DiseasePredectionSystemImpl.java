/**
 */
package diseaseinfo22.impl;

import diseaseinfo22.Disease;
import diseaseinfo22.DiseasePredectionSystem;
import diseaseinfo22.Diseaseinfo22Package;
import diseaseinfo22.Doctors;
import diseaseinfo22.HealthReport;
import diseaseinfo22.Patients;
import diseaseinfo22.Symptoms;

import java.util.Collection;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Disease Predection System</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link diseaseinfo22.impl.DiseasePredectionSystemImpl#getDisease <em>Disease</em>}</li>
 *   <li>{@link diseaseinfo22.impl.DiseasePredectionSystemImpl#getSymptoms <em>Symptoms</em>}</li>
 *   <li>{@link diseaseinfo22.impl.DiseasePredectionSystemImpl#getPatients <em>Patients</em>}</li>
 *   <li>{@link diseaseinfo22.impl.DiseasePredectionSystemImpl#getHealthreport <em>Healthreport</em>}</li>
 *   <li>{@link diseaseinfo22.impl.DiseasePredectionSystemImpl#getDoctors <em>Doctors</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DiseasePredectionSystemImpl extends MinimalEObjectImpl.Container implements DiseasePredectionSystem {
	/**
	 * The cached value of the '{@link #getDisease() <em>Disease</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDisease()
	 * @generated
	 * @ordered
	 */
	protected EList<Disease> disease;

	/**
	 * The cached value of the '{@link #getSymptoms() <em>Symptoms</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSymptoms()
	 * @generated
	 * @ordered
	 */
	protected EList<Symptoms> symptoms;

	/**
	 * The cached value of the '{@link #getPatients() <em>Patients</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPatients()
	 * @generated
	 * @ordered
	 */
	protected EList<Patients> patients;

	/**
	 * The cached value of the '{@link #getHealthreport() <em>Healthreport</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHealthreport()
	 * @generated
	 * @ordered
	 */
	protected EList<HealthReport> healthreport;

	/**
	 * The cached value of the '{@link #getDoctors() <em>Doctors</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoctors()
	 * @generated
	 * @ordered
	 */
	protected EList<Doctors> doctors;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DiseasePredectionSystemImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Diseaseinfo22Package.Literals.DISEASE_PREDECTION_SYSTEM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Disease> getDisease() {
		if (disease == null) {
			disease = new EObjectContainmentEList<Disease>(Disease.class, this,
					Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__DISEASE);
		}
		return disease;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Symptoms> getSymptoms() {
		if (symptoms == null) {
			symptoms = new EObjectContainmentEList<Symptoms>(Symptoms.class, this,
					Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__SYMPTOMS);
		}
		return symptoms;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Doctors> getDoctors() {
		if (doctors == null) {
			doctors = new EObjectContainmentEList<Doctors>(Doctors.class, this,
					Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__DOCTORS);
		}
		return doctors;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<HealthReport> getHealthreport() {
		if (healthreport == null) {
			healthreport = new EObjectContainmentEList<HealthReport>(HealthReport.class, this,
					Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__HEALTHREPORT);
		}
		return healthreport;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Patients> getPatients() {
		if (patients == null) {
			patients = new EObjectContainmentEList<Patients>(Patients.class, this,
					Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__PATIENTS);
		}
		return patients;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__DISEASE:
			return ((InternalEList<?>) getDisease()).basicRemove(otherEnd, msgs);
		case Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__SYMPTOMS:
			return ((InternalEList<?>) getSymptoms()).basicRemove(otherEnd, msgs);
		case Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__PATIENTS:
			return ((InternalEList<?>) getPatients()).basicRemove(otherEnd, msgs);
		case Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__HEALTHREPORT:
			return ((InternalEList<?>) getHealthreport()).basicRemove(otherEnd, msgs);
		case Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__DOCTORS:
			return ((InternalEList<?>) getDoctors()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__DISEASE:
			return getDisease();
		case Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__SYMPTOMS:
			return getSymptoms();
		case Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__PATIENTS:
			return getPatients();
		case Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__HEALTHREPORT:
			return getHealthreport();
		case Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__DOCTORS:
			return getDoctors();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__DISEASE:
			getDisease().clear();
			getDisease().addAll((Collection<? extends Disease>) newValue);
			return;
		case Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__SYMPTOMS:
			getSymptoms().clear();
			getSymptoms().addAll((Collection<? extends Symptoms>) newValue);
			return;
		case Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__PATIENTS:
			getPatients().clear();
			getPatients().addAll((Collection<? extends Patients>) newValue);
			return;
		case Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__HEALTHREPORT:
			getHealthreport().clear();
			getHealthreport().addAll((Collection<? extends HealthReport>) newValue);
			return;
		case Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__DOCTORS:
			getDoctors().clear();
			getDoctors().addAll((Collection<? extends Doctors>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__DISEASE:
			getDisease().clear();
			return;
		case Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__SYMPTOMS:
			getSymptoms().clear();
			return;
		case Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__PATIENTS:
			getPatients().clear();
			return;
		case Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__HEALTHREPORT:
			getHealthreport().clear();
			return;
		case Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__DOCTORS:
			getDoctors().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__DISEASE:
			return disease != null && !disease.isEmpty();
		case Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__SYMPTOMS:
			return symptoms != null && !symptoms.isEmpty();
		case Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__PATIENTS:
			return patients != null && !patients.isEmpty();
		case Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__HEALTHREPORT:
			return healthreport != null && !healthreport.isEmpty();
		case Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__DOCTORS:
			return doctors != null && !doctors.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //DiseasePredectionSystemImpl
