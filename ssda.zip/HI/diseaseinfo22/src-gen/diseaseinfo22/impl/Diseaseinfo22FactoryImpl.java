/**
 */
package diseaseinfo22.impl;

import diseaseinfo22.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class Diseaseinfo22FactoryImpl extends EFactoryImpl implements Diseaseinfo22Factory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static Diseaseinfo22Factory init() {
		try {
			Diseaseinfo22Factory theDiseaseinfo22Factory = (Diseaseinfo22Factory) EPackage.Registry.INSTANCE
					.getEFactory(Diseaseinfo22Package.eNS_URI);
			if (theDiseaseinfo22Factory != null) {
				return theDiseaseinfo22Factory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new Diseaseinfo22FactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Diseaseinfo22FactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM:
			return createDiseasePredectionSystem();
		case Diseaseinfo22Package.DISEASE:
			return createDisease();
		case Diseaseinfo22Package.SYMPTOMS:
			return createSymptoms();
		case Diseaseinfo22Package.PATIENTS:
			return createPatients();
		case Diseaseinfo22Package.HEALTH_REPORT:
			return createHealthReport();
		case Diseaseinfo22Package.DOCTORS:
			return createDoctors();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DiseasePredectionSystem createDiseasePredectionSystem() {
		DiseasePredectionSystemImpl diseasePredectionSystem = new DiseasePredectionSystemImpl();
		return diseasePredectionSystem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Disease createDisease() {
		DiseaseImpl disease = new DiseaseImpl();
		return disease;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Symptoms createSymptoms() {
		SymptomsImpl symptoms = new SymptomsImpl();
		return symptoms;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Patients createPatients() {
		PatientsImpl patients = new PatientsImpl();
		return patients;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public HealthReport createHealthReport() {
		HealthReportImpl healthReport = new HealthReportImpl();
		return healthReport;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Doctors createDoctors() {
		DoctorsImpl doctors = new DoctorsImpl();
		return doctors;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Diseaseinfo22Package getDiseaseinfo22Package() {
		return (Diseaseinfo22Package) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static Diseaseinfo22Package getPackage() {
		return Diseaseinfo22Package.eINSTANCE;
	}

} //Diseaseinfo22FactoryImpl
