/**
 */
package diseaseinfo22.impl;

import diseaseinfo22.Diseaseinfo22Package;
import diseaseinfo22.Doctors;
import diseaseinfo22.HealthReport;
import diseaseinfo22.Patients;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Health Report</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link diseaseinfo22.impl.HealthReportImpl#getType <em>Type</em>}</li>
 *   <li>{@link diseaseinfo22.impl.HealthReportImpl#getNumber <em>Number</em>}</li>
 *   <li>{@link diseaseinfo22.impl.HealthReportImpl#getPatients <em>Patients</em>}</li>
 *   <li>{@link diseaseinfo22.impl.HealthReportImpl#getDoctors <em>Doctors</em>}</li>
 * </ul>
 *
 * @generated
 */
public class HealthReportImpl extends MinimalEObjectImpl.Container implements HealthReport {
	/**
	 * The default value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected static final String TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected String type = TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getNumber() <em>Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNumber()
	 * @generated
	 * @ordered
	 */
	protected static final int NUMBER_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getNumber() <em>Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNumber()
	 * @generated
	 * @ordered
	 */
	protected int number = NUMBER_EDEFAULT;

	/**
	 * The cached value of the '{@link #getPatients() <em>Patients</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPatients()
	 * @generated
	 * @ordered
	 */
	protected Patients patients;

	/**
	 * The cached value of the '{@link #getDoctors() <em>Doctors</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoctors()
	 * @generated
	 * @ordered
	 */
	protected EList<Doctors> doctors;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected HealthReportImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Diseaseinfo22Package.Literals.HEALTH_REPORT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setType(String newType) {
		String oldType = type;
		type = newType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Diseaseinfo22Package.HEALTH_REPORT__TYPE, oldType,
					type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getNumber() {
		return number;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNumber(int newNumber) {
		int oldNumber = number;
		number = newNumber;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Diseaseinfo22Package.HEALTH_REPORT__NUMBER, oldNumber,
					number));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Patients getPatients() {
		if (patients != null && patients.eIsProxy()) {
			InternalEObject oldPatients = (InternalEObject) patients;
			patients = (Patients) eResolveProxy(oldPatients);
			if (patients != oldPatients) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							Diseaseinfo22Package.HEALTH_REPORT__PATIENTS, oldPatients, patients));
			}
		}
		return patients;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Patients basicGetPatients() {
		return patients;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetPatients(Patients newPatients, NotificationChain msgs) {
		Patients oldPatients = patients;
		patients = newPatients;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Diseaseinfo22Package.HEALTH_REPORT__PATIENTS, oldPatients, newPatients);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPatients(Patients newPatients) {
		if (newPatients != patients) {
			NotificationChain msgs = null;
			if (patients != null)
				msgs = ((InternalEObject) patients).eInverseRemove(this, Diseaseinfo22Package.PATIENTS__HEALTHREPORT,
						Patients.class, msgs);
			if (newPatients != null)
				msgs = ((InternalEObject) newPatients).eInverseAdd(this, Diseaseinfo22Package.PATIENTS__HEALTHREPORT,
						Patients.class, msgs);
			msgs = basicSetPatients(newPatients, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Diseaseinfo22Package.HEALTH_REPORT__PATIENTS,
					newPatients, newPatients));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Doctors> getDoctors() {
		if (doctors == null) {
			doctors = new EObjectWithInverseResolvingEList.ManyInverse<Doctors>(Doctors.class, this,
					Diseaseinfo22Package.HEALTH_REPORT__DOCTORS, Diseaseinfo22Package.DOCTORS__HEALTHREPORT);
		}
		return doctors;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Diseaseinfo22Package.HEALTH_REPORT__PATIENTS:
			if (patients != null)
				msgs = ((InternalEObject) patients).eInverseRemove(this, Diseaseinfo22Package.PATIENTS__HEALTHREPORT,
						Patients.class, msgs);
			return basicSetPatients((Patients) otherEnd, msgs);
		case Diseaseinfo22Package.HEALTH_REPORT__DOCTORS:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getDoctors()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Diseaseinfo22Package.HEALTH_REPORT__PATIENTS:
			return basicSetPatients(null, msgs);
		case Diseaseinfo22Package.HEALTH_REPORT__DOCTORS:
			return ((InternalEList<?>) getDoctors()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Diseaseinfo22Package.HEALTH_REPORT__TYPE:
			return getType();
		case Diseaseinfo22Package.HEALTH_REPORT__NUMBER:
			return getNumber();
		case Diseaseinfo22Package.HEALTH_REPORT__PATIENTS:
			if (resolve)
				return getPatients();
			return basicGetPatients();
		case Diseaseinfo22Package.HEALTH_REPORT__DOCTORS:
			return getDoctors();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Diseaseinfo22Package.HEALTH_REPORT__TYPE:
			setType((String) newValue);
			return;
		case Diseaseinfo22Package.HEALTH_REPORT__NUMBER:
			setNumber((Integer) newValue);
			return;
		case Diseaseinfo22Package.HEALTH_REPORT__PATIENTS:
			setPatients((Patients) newValue);
			return;
		case Diseaseinfo22Package.HEALTH_REPORT__DOCTORS:
			getDoctors().clear();
			getDoctors().addAll((Collection<? extends Doctors>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Diseaseinfo22Package.HEALTH_REPORT__TYPE:
			setType(TYPE_EDEFAULT);
			return;
		case Diseaseinfo22Package.HEALTH_REPORT__NUMBER:
			setNumber(NUMBER_EDEFAULT);
			return;
		case Diseaseinfo22Package.HEALTH_REPORT__PATIENTS:
			setPatients((Patients) null);
			return;
		case Diseaseinfo22Package.HEALTH_REPORT__DOCTORS:
			getDoctors().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Diseaseinfo22Package.HEALTH_REPORT__TYPE:
			return TYPE_EDEFAULT == null ? type != null : !TYPE_EDEFAULT.equals(type);
		case Diseaseinfo22Package.HEALTH_REPORT__NUMBER:
			return number != NUMBER_EDEFAULT;
		case Diseaseinfo22Package.HEALTH_REPORT__PATIENTS:
			return patients != null;
		case Diseaseinfo22Package.HEALTH_REPORT__DOCTORS:
			return doctors != null && !doctors.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (type: ");
		result.append(type);
		result.append(", number: ");
		result.append(number);
		result.append(')');
		return result.toString();
	}

} //HealthReportImpl
