/**
 */
package diseaseinfo22.impl;

import diseaseinfo22.Disease;
import diseaseinfo22.Diseaseinfo22Package;
import diseaseinfo22.Doctors;
import diseaseinfo22.HealthReport;
import diseaseinfo22.Patients;
import diseaseinfo22.Symptoms;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Patients</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link diseaseinfo22.impl.PatientsImpl#getName <em>Name</em>}</li>
 *   <li>{@link diseaseinfo22.impl.PatientsImpl#getType <em>Type</em>}</li>
 *   <li>{@link diseaseinfo22.impl.PatientsImpl#getSymptoms <em>Symptoms</em>}</li>
 *   <li>{@link diseaseinfo22.impl.PatientsImpl#getDisease <em>Disease</em>}</li>
 *   <li>{@link diseaseinfo22.impl.PatientsImpl#getDoctors <em>Doctors</em>}</li>
 *   <li>{@link diseaseinfo22.impl.PatientsImpl#getHealthreport <em>Healthreport</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PatientsImpl extends MinimalEObjectImpl.Container implements Patients {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected static final String TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected String type = TYPE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSymptoms() <em>Symptoms</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSymptoms()
	 * @generated
	 * @ordered
	 */
	protected EList<Symptoms> symptoms;

	/**
	 * The cached value of the '{@link #getDisease() <em>Disease</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDisease()
	 * @generated
	 * @ordered
	 */
	protected EList<Disease> disease;

	/**
	 * The cached value of the '{@link #getDoctors() <em>Doctors</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoctors()
	 * @generated
	 * @ordered
	 */
	protected Doctors doctors;

	/**
	 * The cached value of the '{@link #getHealthreport() <em>Healthreport</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHealthreport()
	 * @generated
	 * @ordered
	 */
	protected HealthReport healthreport;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PatientsImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Diseaseinfo22Package.Literals.PATIENTS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Diseaseinfo22Package.PATIENTS__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setType(String newType) {
		String oldType = type;
		type = newType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Diseaseinfo22Package.PATIENTS__TYPE, oldType, type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Symptoms> getSymptoms() {
		if (symptoms == null) {
			symptoms = new EObjectWithInverseResolvingEList<Symptoms>(Symptoms.class, this,
					Diseaseinfo22Package.PATIENTS__SYMPTOMS, Diseaseinfo22Package.SYMPTOMS__PATIENTS);
		}
		return symptoms;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Disease> getDisease() {
		if (disease == null) {
			disease = new EObjectWithInverseResolvingEList<Disease>(Disease.class, this,
					Diseaseinfo22Package.PATIENTS__DISEASE, Diseaseinfo22Package.DISEASE__PATIENTS);
		}
		return disease;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Doctors getDoctors() {
		if (doctors != null && doctors.eIsProxy()) {
			InternalEObject oldDoctors = (InternalEObject) doctors;
			doctors = (Doctors) eResolveProxy(oldDoctors);
			if (doctors != oldDoctors) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Diseaseinfo22Package.PATIENTS__DOCTORS,
							oldDoctors, doctors));
			}
		}
		return doctors;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Doctors basicGetDoctors() {
		return doctors;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetDoctors(Doctors newDoctors, NotificationChain msgs) {
		Doctors oldDoctors = doctors;
		doctors = newDoctors;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Diseaseinfo22Package.PATIENTS__DOCTORS, oldDoctors, newDoctors);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDoctors(Doctors newDoctors) {
		if (newDoctors != doctors) {
			NotificationChain msgs = null;
			if (doctors != null)
				msgs = ((InternalEObject) doctors).eInverseRemove(this, Diseaseinfo22Package.DOCTORS__PATIENTS,
						Doctors.class, msgs);
			if (newDoctors != null)
				msgs = ((InternalEObject) newDoctors).eInverseAdd(this, Diseaseinfo22Package.DOCTORS__PATIENTS,
						Doctors.class, msgs);
			msgs = basicSetDoctors(newDoctors, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Diseaseinfo22Package.PATIENTS__DOCTORS, newDoctors,
					newDoctors));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public HealthReport getHealthreport() {
		if (healthreport != null && healthreport.eIsProxy()) {
			InternalEObject oldHealthreport = (InternalEObject) healthreport;
			healthreport = (HealthReport) eResolveProxy(oldHealthreport);
			if (healthreport != oldHealthreport) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							Diseaseinfo22Package.PATIENTS__HEALTHREPORT, oldHealthreport, healthreport));
			}
		}
		return healthreport;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public HealthReport basicGetHealthreport() {
		return healthreport;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetHealthreport(HealthReport newHealthreport, NotificationChain msgs) {
		HealthReport oldHealthreport = healthreport;
		healthreport = newHealthreport;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Diseaseinfo22Package.PATIENTS__HEALTHREPORT, oldHealthreport, newHealthreport);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setHealthreport(HealthReport newHealthreport) {
		if (newHealthreport != healthreport) {
			NotificationChain msgs = null;
			if (healthreport != null)
				msgs = ((InternalEObject) healthreport).eInverseRemove(this,
						Diseaseinfo22Package.HEALTH_REPORT__PATIENTS, HealthReport.class, msgs);
			if (newHealthreport != null)
				msgs = ((InternalEObject) newHealthreport).eInverseAdd(this,
						Diseaseinfo22Package.HEALTH_REPORT__PATIENTS, HealthReport.class, msgs);
			msgs = basicSetHealthreport(newHealthreport, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Diseaseinfo22Package.PATIENTS__HEALTHREPORT,
					newHealthreport, newHealthreport));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Diseaseinfo22Package.PATIENTS__SYMPTOMS:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getSymptoms()).basicAdd(otherEnd, msgs);
		case Diseaseinfo22Package.PATIENTS__DISEASE:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getDisease()).basicAdd(otherEnd, msgs);
		case Diseaseinfo22Package.PATIENTS__DOCTORS:
			if (doctors != null)
				msgs = ((InternalEObject) doctors).eInverseRemove(this, Diseaseinfo22Package.DOCTORS__PATIENTS,
						Doctors.class, msgs);
			return basicSetDoctors((Doctors) otherEnd, msgs);
		case Diseaseinfo22Package.PATIENTS__HEALTHREPORT:
			if (healthreport != null)
				msgs = ((InternalEObject) healthreport).eInverseRemove(this,
						Diseaseinfo22Package.HEALTH_REPORT__PATIENTS, HealthReport.class, msgs);
			return basicSetHealthreport((HealthReport) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Diseaseinfo22Package.PATIENTS__SYMPTOMS:
			return ((InternalEList<?>) getSymptoms()).basicRemove(otherEnd, msgs);
		case Diseaseinfo22Package.PATIENTS__DISEASE:
			return ((InternalEList<?>) getDisease()).basicRemove(otherEnd, msgs);
		case Diseaseinfo22Package.PATIENTS__DOCTORS:
			return basicSetDoctors(null, msgs);
		case Diseaseinfo22Package.PATIENTS__HEALTHREPORT:
			return basicSetHealthreport(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Diseaseinfo22Package.PATIENTS__NAME:
			return getName();
		case Diseaseinfo22Package.PATIENTS__TYPE:
			return getType();
		case Diseaseinfo22Package.PATIENTS__SYMPTOMS:
			return getSymptoms();
		case Diseaseinfo22Package.PATIENTS__DISEASE:
			return getDisease();
		case Diseaseinfo22Package.PATIENTS__DOCTORS:
			if (resolve)
				return getDoctors();
			return basicGetDoctors();
		case Diseaseinfo22Package.PATIENTS__HEALTHREPORT:
			if (resolve)
				return getHealthreport();
			return basicGetHealthreport();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Diseaseinfo22Package.PATIENTS__NAME:
			setName((String) newValue);
			return;
		case Diseaseinfo22Package.PATIENTS__TYPE:
			setType((String) newValue);
			return;
		case Diseaseinfo22Package.PATIENTS__SYMPTOMS:
			getSymptoms().clear();
			getSymptoms().addAll((Collection<? extends Symptoms>) newValue);
			return;
		case Diseaseinfo22Package.PATIENTS__DISEASE:
			getDisease().clear();
			getDisease().addAll((Collection<? extends Disease>) newValue);
			return;
		case Diseaseinfo22Package.PATIENTS__DOCTORS:
			setDoctors((Doctors) newValue);
			return;
		case Diseaseinfo22Package.PATIENTS__HEALTHREPORT:
			setHealthreport((HealthReport) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Diseaseinfo22Package.PATIENTS__NAME:
			setName(NAME_EDEFAULT);
			return;
		case Diseaseinfo22Package.PATIENTS__TYPE:
			setType(TYPE_EDEFAULT);
			return;
		case Diseaseinfo22Package.PATIENTS__SYMPTOMS:
			getSymptoms().clear();
			return;
		case Diseaseinfo22Package.PATIENTS__DISEASE:
			getDisease().clear();
			return;
		case Diseaseinfo22Package.PATIENTS__DOCTORS:
			setDoctors((Doctors) null);
			return;
		case Diseaseinfo22Package.PATIENTS__HEALTHREPORT:
			setHealthreport((HealthReport) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Diseaseinfo22Package.PATIENTS__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case Diseaseinfo22Package.PATIENTS__TYPE:
			return TYPE_EDEFAULT == null ? type != null : !TYPE_EDEFAULT.equals(type);
		case Diseaseinfo22Package.PATIENTS__SYMPTOMS:
			return symptoms != null && !symptoms.isEmpty();
		case Diseaseinfo22Package.PATIENTS__DISEASE:
			return disease != null && !disease.isEmpty();
		case Diseaseinfo22Package.PATIENTS__DOCTORS:
			return doctors != null;
		case Diseaseinfo22Package.PATIENTS__HEALTHREPORT:
			return healthreport != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", type: ");
		result.append(type);
		result.append(')');
		return result.toString();
	}

} //PatientsImpl
