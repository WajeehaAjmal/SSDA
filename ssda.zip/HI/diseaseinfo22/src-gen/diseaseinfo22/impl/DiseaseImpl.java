/**
 */
package diseaseinfo22.impl;

import diseaseinfo22.Disease;
import diseaseinfo22.Diseaseinfo22Package;
import diseaseinfo22.Patients;
import diseaseinfo22.Symptoms;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Disease</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link diseaseinfo22.impl.DiseaseImpl#getName <em>Name</em>}</li>
 *   <li>{@link diseaseinfo22.impl.DiseaseImpl#getType <em>Type</em>}</li>
 *   <li>{@link diseaseinfo22.impl.DiseaseImpl#getSymptoms <em>Symptoms</em>}</li>
 *   <li>{@link diseaseinfo22.impl.DiseaseImpl#getPatients <em>Patients</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DiseaseImpl extends MinimalEObjectImpl.Container implements Disease {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected static final String TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected String type = TYPE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSymptoms() <em>Symptoms</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSymptoms()
	 * @generated
	 * @ordered
	 */
	protected EList<Symptoms> symptoms;

	/**
	 * The cached value of the '{@link #getPatients() <em>Patients</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPatients()
	 * @generated
	 * @ordered
	 */
	protected Patients patients;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DiseaseImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Diseaseinfo22Package.Literals.DISEASE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Diseaseinfo22Package.DISEASE__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setType(String newType) {
		String oldType = type;
		type = newType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Diseaseinfo22Package.DISEASE__TYPE, oldType, type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Symptoms> getSymptoms() {
		if (symptoms == null) {
			symptoms = new EObjectWithInverseResolvingEList.ManyInverse<Symptoms>(Symptoms.class, this,
					Diseaseinfo22Package.DISEASE__SYMPTOMS, Diseaseinfo22Package.SYMPTOMS__DISEASE);
		}
		return symptoms;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Patients getPatients() {
		if (patients != null && patients.eIsProxy()) {
			InternalEObject oldPatients = (InternalEObject) patients;
			patients = (Patients) eResolveProxy(oldPatients);
			if (patients != oldPatients) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Diseaseinfo22Package.DISEASE__PATIENTS,
							oldPatients, patients));
			}
		}
		return patients;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Patients basicGetPatients() {
		return patients;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetPatients(Patients newPatients, NotificationChain msgs) {
		Patients oldPatients = patients;
		patients = newPatients;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Diseaseinfo22Package.DISEASE__PATIENTS, oldPatients, newPatients);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPatients(Patients newPatients) {
		if (newPatients != patients) {
			NotificationChain msgs = null;
			if (patients != null)
				msgs = ((InternalEObject) patients).eInverseRemove(this, Diseaseinfo22Package.PATIENTS__DISEASE,
						Patients.class, msgs);
			if (newPatients != null)
				msgs = ((InternalEObject) newPatients).eInverseAdd(this, Diseaseinfo22Package.PATIENTS__DISEASE,
						Patients.class, msgs);
			msgs = basicSetPatients(newPatients, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Diseaseinfo22Package.DISEASE__PATIENTS, newPatients,
					newPatients));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Diseaseinfo22Package.DISEASE__SYMPTOMS:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getSymptoms()).basicAdd(otherEnd, msgs);
		case Diseaseinfo22Package.DISEASE__PATIENTS:
			if (patients != null)
				msgs = ((InternalEObject) patients).eInverseRemove(this, Diseaseinfo22Package.PATIENTS__DISEASE,
						Patients.class, msgs);
			return basicSetPatients((Patients) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Diseaseinfo22Package.DISEASE__SYMPTOMS:
			return ((InternalEList<?>) getSymptoms()).basicRemove(otherEnd, msgs);
		case Diseaseinfo22Package.DISEASE__PATIENTS:
			return basicSetPatients(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Diseaseinfo22Package.DISEASE__NAME:
			return getName();
		case Diseaseinfo22Package.DISEASE__TYPE:
			return getType();
		case Diseaseinfo22Package.DISEASE__SYMPTOMS:
			return getSymptoms();
		case Diseaseinfo22Package.DISEASE__PATIENTS:
			if (resolve)
				return getPatients();
			return basicGetPatients();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Diseaseinfo22Package.DISEASE__NAME:
			setName((String) newValue);
			return;
		case Diseaseinfo22Package.DISEASE__TYPE:
			setType((String) newValue);
			return;
		case Diseaseinfo22Package.DISEASE__SYMPTOMS:
			getSymptoms().clear();
			getSymptoms().addAll((Collection<? extends Symptoms>) newValue);
			return;
		case Diseaseinfo22Package.DISEASE__PATIENTS:
			setPatients((Patients) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Diseaseinfo22Package.DISEASE__NAME:
			setName(NAME_EDEFAULT);
			return;
		case Diseaseinfo22Package.DISEASE__TYPE:
			setType(TYPE_EDEFAULT);
			return;
		case Diseaseinfo22Package.DISEASE__SYMPTOMS:
			getSymptoms().clear();
			return;
		case Diseaseinfo22Package.DISEASE__PATIENTS:
			setPatients((Patients) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Diseaseinfo22Package.DISEASE__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case Diseaseinfo22Package.DISEASE__TYPE:
			return TYPE_EDEFAULT == null ? type != null : !TYPE_EDEFAULT.equals(type);
		case Diseaseinfo22Package.DISEASE__SYMPTOMS:
			return symptoms != null && !symptoms.isEmpty();
		case Diseaseinfo22Package.DISEASE__PATIENTS:
			return patients != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", type: ");
		result.append(type);
		result.append(')');
		return result.toString();
	}

} //DiseaseImpl
