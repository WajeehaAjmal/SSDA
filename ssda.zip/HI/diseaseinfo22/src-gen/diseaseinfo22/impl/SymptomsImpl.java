/**
 */
package diseaseinfo22.impl;

import diseaseinfo22.Disease;
import diseaseinfo22.Diseaseinfo22Package;
import diseaseinfo22.Patients;
import diseaseinfo22.Symptoms;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Symptoms</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link diseaseinfo22.impl.SymptomsImpl#getTypes <em>Types</em>}</li>
 *   <li>{@link diseaseinfo22.impl.SymptomsImpl#getNumberofsymp <em>Numberofsymp</em>}</li>
 *   <li>{@link diseaseinfo22.impl.SymptomsImpl#getDisease <em>Disease</em>}</li>
 *   <li>{@link diseaseinfo22.impl.SymptomsImpl#getPatients <em>Patients</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SymptomsImpl extends MinimalEObjectImpl.Container implements Symptoms {
	/**
	 * The default value of the '{@link #getTypes() <em>Types</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTypes()
	 * @generated
	 * @ordered
	 */
	protected static final String TYPES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTypes() <em>Types</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTypes()
	 * @generated
	 * @ordered
	 */
	protected String types = TYPES_EDEFAULT;

	/**
	 * The default value of the '{@link #getNumberofsymp() <em>Numberofsymp</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNumberofsymp()
	 * @generated
	 * @ordered
	 */
	protected static final int NUMBEROFSYMP_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getNumberofsymp() <em>Numberofsymp</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNumberofsymp()
	 * @generated
	 * @ordered
	 */
	protected int numberofsymp = NUMBEROFSYMP_EDEFAULT;

	/**
	 * The cached value of the '{@link #getDisease() <em>Disease</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDisease()
	 * @generated
	 * @ordered
	 */
	protected EList<Disease> disease;

	/**
	 * The cached value of the '{@link #getPatients() <em>Patients</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPatients()
	 * @generated
	 * @ordered
	 */
	protected Patients patients;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SymptomsImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Diseaseinfo22Package.Literals.SYMPTOMS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getTypes() {
		return types;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTypes(String newTypes) {
		String oldTypes = types;
		types = newTypes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Diseaseinfo22Package.SYMPTOMS__TYPES, oldTypes,
					types));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getNumberofsymp() {
		return numberofsymp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNumberofsymp(int newNumberofsymp) {
		int oldNumberofsymp = numberofsymp;
		numberofsymp = newNumberofsymp;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Diseaseinfo22Package.SYMPTOMS__NUMBEROFSYMP,
					oldNumberofsymp, numberofsymp));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Disease> getDisease() {
		if (disease == null) {
			disease = new EObjectWithInverseResolvingEList.ManyInverse<Disease>(Disease.class, this,
					Diseaseinfo22Package.SYMPTOMS__DISEASE, Diseaseinfo22Package.DISEASE__SYMPTOMS);
		}
		return disease;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Patients getPatients() {
		if (patients != null && patients.eIsProxy()) {
			InternalEObject oldPatients = (InternalEObject) patients;
			patients = (Patients) eResolveProxy(oldPatients);
			if (patients != oldPatients) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Diseaseinfo22Package.SYMPTOMS__PATIENTS,
							oldPatients, patients));
			}
		}
		return patients;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Patients basicGetPatients() {
		return patients;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetPatients(Patients newPatients, NotificationChain msgs) {
		Patients oldPatients = patients;
		patients = newPatients;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Diseaseinfo22Package.SYMPTOMS__PATIENTS, oldPatients, newPatients);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPatients(Patients newPatients) {
		if (newPatients != patients) {
			NotificationChain msgs = null;
			if (patients != null)
				msgs = ((InternalEObject) patients).eInverseRemove(this, Diseaseinfo22Package.PATIENTS__SYMPTOMS,
						Patients.class, msgs);
			if (newPatients != null)
				msgs = ((InternalEObject) newPatients).eInverseAdd(this, Diseaseinfo22Package.PATIENTS__SYMPTOMS,
						Patients.class, msgs);
			msgs = basicSetPatients(newPatients, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Diseaseinfo22Package.SYMPTOMS__PATIENTS, newPatients,
					newPatients));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Diseaseinfo22Package.SYMPTOMS__DISEASE:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getDisease()).basicAdd(otherEnd, msgs);
		case Diseaseinfo22Package.SYMPTOMS__PATIENTS:
			if (patients != null)
				msgs = ((InternalEObject) patients).eInverseRemove(this, Diseaseinfo22Package.PATIENTS__SYMPTOMS,
						Patients.class, msgs);
			return basicSetPatients((Patients) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Diseaseinfo22Package.SYMPTOMS__DISEASE:
			return ((InternalEList<?>) getDisease()).basicRemove(otherEnd, msgs);
		case Diseaseinfo22Package.SYMPTOMS__PATIENTS:
			return basicSetPatients(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Diseaseinfo22Package.SYMPTOMS__TYPES:
			return getTypes();
		case Diseaseinfo22Package.SYMPTOMS__NUMBEROFSYMP:
			return getNumberofsymp();
		case Diseaseinfo22Package.SYMPTOMS__DISEASE:
			return getDisease();
		case Diseaseinfo22Package.SYMPTOMS__PATIENTS:
			if (resolve)
				return getPatients();
			return basicGetPatients();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Diseaseinfo22Package.SYMPTOMS__TYPES:
			setTypes((String) newValue);
			return;
		case Diseaseinfo22Package.SYMPTOMS__NUMBEROFSYMP:
			setNumberofsymp((Integer) newValue);
			return;
		case Diseaseinfo22Package.SYMPTOMS__DISEASE:
			getDisease().clear();
			getDisease().addAll((Collection<? extends Disease>) newValue);
			return;
		case Diseaseinfo22Package.SYMPTOMS__PATIENTS:
			setPatients((Patients) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Diseaseinfo22Package.SYMPTOMS__TYPES:
			setTypes(TYPES_EDEFAULT);
			return;
		case Diseaseinfo22Package.SYMPTOMS__NUMBEROFSYMP:
			setNumberofsymp(NUMBEROFSYMP_EDEFAULT);
			return;
		case Diseaseinfo22Package.SYMPTOMS__DISEASE:
			getDisease().clear();
			return;
		case Diseaseinfo22Package.SYMPTOMS__PATIENTS:
			setPatients((Patients) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Diseaseinfo22Package.SYMPTOMS__TYPES:
			return TYPES_EDEFAULT == null ? types != null : !TYPES_EDEFAULT.equals(types);
		case Diseaseinfo22Package.SYMPTOMS__NUMBEROFSYMP:
			return numberofsymp != NUMBEROFSYMP_EDEFAULT;
		case Diseaseinfo22Package.SYMPTOMS__DISEASE:
			return disease != null && !disease.isEmpty();
		case Diseaseinfo22Package.SYMPTOMS__PATIENTS:
			return patients != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (types: ");
		result.append(types);
		result.append(", numberofsymp: ");
		result.append(numberofsymp);
		result.append(')');
		return result.toString();
	}

} //SymptomsImpl
