/**
 */
package diseaseinfo22.impl;

import diseaseinfo22.Disease;
import diseaseinfo22.DiseasePredectionSystem;
import diseaseinfo22.Diseaseinfo22Factory;
import diseaseinfo22.Diseaseinfo22Package;
import diseaseinfo22.Doctors;
import diseaseinfo22.HealthReport;
import diseaseinfo22.Patients;
import diseaseinfo22.Symptoms;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class Diseaseinfo22PackageImpl extends EPackageImpl implements Diseaseinfo22Package {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass diseasePredectionSystemEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass diseaseEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass symptomsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass patientsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass healthReportEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass doctorsEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see diseaseinfo22.Diseaseinfo22Package#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private Diseaseinfo22PackageImpl() {
		super(eNS_URI, Diseaseinfo22Factory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link Diseaseinfo22Package#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static Diseaseinfo22Package init() {
		if (isInited)
			return (Diseaseinfo22Package) EPackage.Registry.INSTANCE.getEPackage(Diseaseinfo22Package.eNS_URI);

		// Obtain or create and register package
		Object registeredDiseaseinfo22Package = EPackage.Registry.INSTANCE.get(eNS_URI);
		Diseaseinfo22PackageImpl theDiseaseinfo22Package = registeredDiseaseinfo22Package instanceof Diseaseinfo22PackageImpl
				? (Diseaseinfo22PackageImpl) registeredDiseaseinfo22Package
				: new Diseaseinfo22PackageImpl();

		isInited = true;

		// Create package meta-data objects
		theDiseaseinfo22Package.createPackageContents();

		// Initialize created meta-data
		theDiseaseinfo22Package.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theDiseaseinfo22Package.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(Diseaseinfo22Package.eNS_URI, theDiseaseinfo22Package);
		return theDiseaseinfo22Package;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDiseasePredectionSystem() {
		return diseasePredectionSystemEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDiseasePredectionSystem_Disease() {
		return (EReference) diseasePredectionSystemEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDiseasePredectionSystem_Symptoms() {
		return (EReference) diseasePredectionSystemEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDiseasePredectionSystem_Doctors() {
		return (EReference) diseasePredectionSystemEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDiseasePredectionSystem_Healthreport() {
		return (EReference) diseasePredectionSystemEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDiseasePredectionSystem_Patients() {
		return (EReference) diseasePredectionSystemEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDisease() {
		return diseaseEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDisease_Name() {
		return (EAttribute) diseaseEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDisease_Type() {
		return (EAttribute) diseaseEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDisease_Symptoms() {
		return (EReference) diseaseEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDisease_Patients() {
		return (EReference) diseaseEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSymptoms() {
		return symptomsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSymptoms_Types() {
		return (EAttribute) symptomsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSymptoms_Numberofsymp() {
		return (EAttribute) symptomsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSymptoms_Disease() {
		return (EReference) symptomsEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSymptoms_Patients() {
		return (EReference) symptomsEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPatients() {
		return patientsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPatients_Name() {
		return (EAttribute) patientsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPatients_Type() {
		return (EAttribute) patientsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPatients_Symptoms() {
		return (EReference) patientsEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPatients_Disease() {
		return (EReference) patientsEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPatients_Doctors() {
		return (EReference) patientsEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPatients_Healthreport() {
		return (EReference) patientsEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getHealthReport() {
		return healthReportEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getHealthReport_Type() {
		return (EAttribute) healthReportEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getHealthReport_Number() {
		return (EAttribute) healthReportEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHealthReport_Patients() {
		return (EReference) healthReportEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHealthReport_Doctors() {
		return (EReference) healthReportEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDoctors() {
		return doctorsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDoctors_Type() {
		return (EAttribute) doctorsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDoctors_Name() {
		return (EAttribute) doctorsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDoctors_Patients() {
		return (EReference) doctorsEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDoctors_Healthreport() {
		return (EReference) doctorsEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Diseaseinfo22Factory getDiseaseinfo22Factory() {
		return (Diseaseinfo22Factory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		diseasePredectionSystemEClass = createEClass(DISEASE_PREDECTION_SYSTEM);
		createEReference(diseasePredectionSystemEClass, DISEASE_PREDECTION_SYSTEM__DISEASE);
		createEReference(diseasePredectionSystemEClass, DISEASE_PREDECTION_SYSTEM__SYMPTOMS);
		createEReference(diseasePredectionSystemEClass, DISEASE_PREDECTION_SYSTEM__PATIENTS);
		createEReference(diseasePredectionSystemEClass, DISEASE_PREDECTION_SYSTEM__HEALTHREPORT);
		createEReference(diseasePredectionSystemEClass, DISEASE_PREDECTION_SYSTEM__DOCTORS);

		diseaseEClass = createEClass(DISEASE);
		createEAttribute(diseaseEClass, DISEASE__NAME);
		createEAttribute(diseaseEClass, DISEASE__TYPE);
		createEReference(diseaseEClass, DISEASE__SYMPTOMS);
		createEReference(diseaseEClass, DISEASE__PATIENTS);

		symptomsEClass = createEClass(SYMPTOMS);
		createEAttribute(symptomsEClass, SYMPTOMS__TYPES);
		createEAttribute(symptomsEClass, SYMPTOMS__NUMBEROFSYMP);
		createEReference(symptomsEClass, SYMPTOMS__DISEASE);
		createEReference(symptomsEClass, SYMPTOMS__PATIENTS);

		patientsEClass = createEClass(PATIENTS);
		createEAttribute(patientsEClass, PATIENTS__NAME);
		createEAttribute(patientsEClass, PATIENTS__TYPE);
		createEReference(patientsEClass, PATIENTS__SYMPTOMS);
		createEReference(patientsEClass, PATIENTS__DISEASE);
		createEReference(patientsEClass, PATIENTS__DOCTORS);
		createEReference(patientsEClass, PATIENTS__HEALTHREPORT);

		healthReportEClass = createEClass(HEALTH_REPORT);
		createEAttribute(healthReportEClass, HEALTH_REPORT__TYPE);
		createEAttribute(healthReportEClass, HEALTH_REPORT__NUMBER);
		createEReference(healthReportEClass, HEALTH_REPORT__PATIENTS);
		createEReference(healthReportEClass, HEALTH_REPORT__DOCTORS);

		doctorsEClass = createEClass(DOCTORS);
		createEAttribute(doctorsEClass, DOCTORS__TYPE);
		createEAttribute(doctorsEClass, DOCTORS__NAME);
		createEReference(doctorsEClass, DOCTORS__PATIENTS);
		createEReference(doctorsEClass, DOCTORS__HEALTHREPORT);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes

		// Initialize classes, features, and operations; add parameters
		initEClass(diseasePredectionSystemEClass, DiseasePredectionSystem.class, "DiseasePredectionSystem",
				!IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getDiseasePredectionSystem_Disease(), this.getDisease(), null, "disease", null, 0, -1,
				DiseasePredectionSystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDiseasePredectionSystem_Symptoms(), this.getSymptoms(), null, "symptoms", null, 0, -1,
				DiseasePredectionSystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDiseasePredectionSystem_Patients(), this.getPatients(), null, "patients", null, 0, -1,
				DiseasePredectionSystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDiseasePredectionSystem_Healthreport(), this.getHealthReport(), null, "healthreport", null, 0,
				-1, DiseasePredectionSystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDiseasePredectionSystem_Doctors(), this.getDoctors(), null, "doctors", null, 0, -1,
				DiseasePredectionSystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(diseaseEClass, Disease.class, "Disease", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDisease_Name(), ecorePackage.getEString(), "name", null, 0, 1, Disease.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDisease_Type(), ecorePackage.getEString(), "type", null, 0, 1, Disease.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDisease_Symptoms(), this.getSymptoms(), this.getSymptoms_Disease(), "symptoms", null, 1, -1,
				Disease.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDisease_Patients(), this.getPatients(), this.getPatients_Disease(), "patients", null, 1, 1,
				Disease.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(symptomsEClass, Symptoms.class, "Symptoms", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSymptoms_Types(), ecorePackage.getEString(), "types", null, 0, 1, Symptoms.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSymptoms_Numberofsymp(), ecorePackage.getEInt(), "numberofsymp", null, 0, 1, Symptoms.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSymptoms_Disease(), this.getDisease(), this.getDisease_Symptoms(), "disease", null, 1, -1,
				Symptoms.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSymptoms_Patients(), this.getPatients(), this.getPatients_Symptoms(), "patients", null, 1, 1,
				Symptoms.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(patientsEClass, Patients.class, "Patients", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPatients_Name(), ecorePackage.getEString(), "name", null, 0, 1, Patients.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPatients_Type(), ecorePackage.getEString(), "type", null, 0, 1, Patients.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPatients_Symptoms(), this.getSymptoms(), this.getSymptoms_Patients(), "symptoms", null, 1, -1,
				Patients.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPatients_Disease(), this.getDisease(), this.getDisease_Patients(), "disease", null, 0, -1,
				Patients.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPatients_Doctors(), this.getDoctors(), this.getDoctors_Patients(), "doctors", null, 1, 1,
				Patients.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPatients_Healthreport(), this.getHealthReport(), this.getHealthReport_Patients(),
				"healthreport", null, 1, 1, Patients.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(healthReportEClass, HealthReport.class, "HealthReport", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getHealthReport_Type(), ecorePackage.getEString(), "type", null, 0, 1, HealthReport.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getHealthReport_Number(), ecorePackage.getEInt(), "number", null, 0, 1, HealthReport.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHealthReport_Patients(), this.getPatients(), this.getPatients_Healthreport(), "patients",
				null, 1, 1, HealthReport.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHealthReport_Doctors(), this.getDoctors(), this.getDoctors_Healthreport(), "doctors", null, 1,
				-1, HealthReport.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(doctorsEClass, Doctors.class, "Doctors", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDoctors_Type(), ecorePackage.getEString(), "type", null, 0, 1, Doctors.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDoctors_Name(), ecorePackage.getEString(), "name", null, 0, 1, Doctors.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDoctors_Patients(), this.getPatients(), this.getPatients_Doctors(), "patients", null, 1, -1,
				Doctors.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDoctors_Healthreport(), this.getHealthReport(), this.getHealthReport_Doctors(),
				"healthreport", null, 1, -1, Doctors.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Create resource
		createResource(eNS_URI);
	}

} //Diseaseinfo22PackageImpl
