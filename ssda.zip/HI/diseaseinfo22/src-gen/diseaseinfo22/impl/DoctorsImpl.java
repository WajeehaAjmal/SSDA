/**
 */
package diseaseinfo22.impl;

import diseaseinfo22.Diseaseinfo22Package;
import diseaseinfo22.Doctors;
import diseaseinfo22.HealthReport;
import diseaseinfo22.Patients;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Doctors</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link diseaseinfo22.impl.DoctorsImpl#getType <em>Type</em>}</li>
 *   <li>{@link diseaseinfo22.impl.DoctorsImpl#getName <em>Name</em>}</li>
 *   <li>{@link diseaseinfo22.impl.DoctorsImpl#getPatients <em>Patients</em>}</li>
 *   <li>{@link diseaseinfo22.impl.DoctorsImpl#getHealthreport <em>Healthreport</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DoctorsImpl extends MinimalEObjectImpl.Container implements Doctors {
	/**
	 * The default value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected static final String TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected String type = TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getPatients() <em>Patients</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPatients()
	 * @generated
	 * @ordered
	 */
	protected EList<Patients> patients;

	/**
	 * The cached value of the '{@link #getHealthreport() <em>Healthreport</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHealthreport()
	 * @generated
	 * @ordered
	 */
	protected EList<HealthReport> healthreport;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DoctorsImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Diseaseinfo22Package.Literals.DOCTORS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setType(String newType) {
		String oldType = type;
		type = newType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Diseaseinfo22Package.DOCTORS__TYPE, oldType, type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Diseaseinfo22Package.DOCTORS__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Patients> getPatients() {
		if (patients == null) {
			patients = new EObjectWithInverseResolvingEList<Patients>(Patients.class, this,
					Diseaseinfo22Package.DOCTORS__PATIENTS, Diseaseinfo22Package.PATIENTS__DOCTORS);
		}
		return patients;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<HealthReport> getHealthreport() {
		if (healthreport == null) {
			healthreport = new EObjectWithInverseResolvingEList.ManyInverse<HealthReport>(HealthReport.class, this,
					Diseaseinfo22Package.DOCTORS__HEALTHREPORT, Diseaseinfo22Package.HEALTH_REPORT__DOCTORS);
		}
		return healthreport;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Diseaseinfo22Package.DOCTORS__PATIENTS:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getPatients()).basicAdd(otherEnd, msgs);
		case Diseaseinfo22Package.DOCTORS__HEALTHREPORT:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getHealthreport()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Diseaseinfo22Package.DOCTORS__PATIENTS:
			return ((InternalEList<?>) getPatients()).basicRemove(otherEnd, msgs);
		case Diseaseinfo22Package.DOCTORS__HEALTHREPORT:
			return ((InternalEList<?>) getHealthreport()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Diseaseinfo22Package.DOCTORS__TYPE:
			return getType();
		case Diseaseinfo22Package.DOCTORS__NAME:
			return getName();
		case Diseaseinfo22Package.DOCTORS__PATIENTS:
			return getPatients();
		case Diseaseinfo22Package.DOCTORS__HEALTHREPORT:
			return getHealthreport();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Diseaseinfo22Package.DOCTORS__TYPE:
			setType((String) newValue);
			return;
		case Diseaseinfo22Package.DOCTORS__NAME:
			setName((String) newValue);
			return;
		case Diseaseinfo22Package.DOCTORS__PATIENTS:
			getPatients().clear();
			getPatients().addAll((Collection<? extends Patients>) newValue);
			return;
		case Diseaseinfo22Package.DOCTORS__HEALTHREPORT:
			getHealthreport().clear();
			getHealthreport().addAll((Collection<? extends HealthReport>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Diseaseinfo22Package.DOCTORS__TYPE:
			setType(TYPE_EDEFAULT);
			return;
		case Diseaseinfo22Package.DOCTORS__NAME:
			setName(NAME_EDEFAULT);
			return;
		case Diseaseinfo22Package.DOCTORS__PATIENTS:
			getPatients().clear();
			return;
		case Diseaseinfo22Package.DOCTORS__HEALTHREPORT:
			getHealthreport().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Diseaseinfo22Package.DOCTORS__TYPE:
			return TYPE_EDEFAULT == null ? type != null : !TYPE_EDEFAULT.equals(type);
		case Diseaseinfo22Package.DOCTORS__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case Diseaseinfo22Package.DOCTORS__PATIENTS:
			return patients != null && !patients.isEmpty();
		case Diseaseinfo22Package.DOCTORS__HEALTHREPORT:
			return healthreport != null && !healthreport.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (type: ");
		result.append(type);
		result.append(", name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //DoctorsImpl
