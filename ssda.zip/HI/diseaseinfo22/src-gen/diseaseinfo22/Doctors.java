/**
 */
package diseaseinfo22;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Doctors</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link diseaseinfo22.Doctors#getType <em>Type</em>}</li>
 *   <li>{@link diseaseinfo22.Doctors#getName <em>Name</em>}</li>
 *   <li>{@link diseaseinfo22.Doctors#getPatients <em>Patients</em>}</li>
 *   <li>{@link diseaseinfo22.Doctors#getHealthreport <em>Healthreport</em>}</li>
 * </ul>
 *
 * @see diseaseinfo22.Diseaseinfo22Package#getDoctors()
 * @model
 * @generated
 */
public interface Doctors extends EObject {
	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see #setType(String)
	 * @see diseaseinfo22.Diseaseinfo22Package#getDoctors_Type()
	 * @model
	 * @generated
	 */
	String getType();

	/**
	 * Sets the value of the '{@link diseaseinfo22.Doctors#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see #getType()
	 * @generated
	 */
	void setType(String value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see diseaseinfo22.Diseaseinfo22Package#getDoctors_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link diseaseinfo22.Doctors#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Patients</b></em>' reference list.
	 * The list contents are of type {@link diseaseinfo22.Patients}.
	 * It is bidirectional and its opposite is '{@link diseaseinfo22.Patients#getDoctors <em>Doctors</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Patients</em>' reference list.
	 * @see diseaseinfo22.Diseaseinfo22Package#getDoctors_Patients()
	 * @see diseaseinfo22.Patients#getDoctors
	 * @model opposite="doctors" required="true"
	 * @generated
	 */
	EList<Patients> getPatients();

	/**
	 * Returns the value of the '<em><b>Healthreport</b></em>' reference list.
	 * The list contents are of type {@link diseaseinfo22.HealthReport}.
	 * It is bidirectional and its opposite is '{@link diseaseinfo22.HealthReport#getDoctors <em>Doctors</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Healthreport</em>' reference list.
	 * @see diseaseinfo22.Diseaseinfo22Package#getDoctors_Healthreport()
	 * @see diseaseinfo22.HealthReport#getDoctors
	 * @model opposite="doctors" required="true"
	 * @generated
	 */
	EList<HealthReport> getHealthreport();

} // Doctors
