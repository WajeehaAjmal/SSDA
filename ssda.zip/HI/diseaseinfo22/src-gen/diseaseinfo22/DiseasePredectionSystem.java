/**
 */
package diseaseinfo22;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Disease Predection System</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link diseaseinfo22.DiseasePredectionSystem#getDisease <em>Disease</em>}</li>
 *   <li>{@link diseaseinfo22.DiseasePredectionSystem#getSymptoms <em>Symptoms</em>}</li>
 *   <li>{@link diseaseinfo22.DiseasePredectionSystem#getPatients <em>Patients</em>}</li>
 *   <li>{@link diseaseinfo22.DiseasePredectionSystem#getHealthreport <em>Healthreport</em>}</li>
 *   <li>{@link diseaseinfo22.DiseasePredectionSystem#getDoctors <em>Doctors</em>}</li>
 * </ul>
 *
 * @see diseaseinfo22.Diseaseinfo22Package#getDiseasePredectionSystem()
 * @model
 * @generated
 */
public interface DiseasePredectionSystem extends EObject {
	/**
	 * Returns the value of the '<em><b>Disease</b></em>' containment reference list.
	 * The list contents are of type {@link diseaseinfo22.Disease}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Disease</em>' containment reference list.
	 * @see diseaseinfo22.Diseaseinfo22Package#getDiseasePredectionSystem_Disease()
	 * @model containment="true"
	 * @generated
	 */
	EList<Disease> getDisease();

	/**
	 * Returns the value of the '<em><b>Symptoms</b></em>' containment reference list.
	 * The list contents are of type {@link diseaseinfo22.Symptoms}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Symptoms</em>' containment reference list.
	 * @see diseaseinfo22.Diseaseinfo22Package#getDiseasePredectionSystem_Symptoms()
	 * @model containment="true"
	 * @generated
	 */
	EList<Symptoms> getSymptoms();

	/**
	 * Returns the value of the '<em><b>Doctors</b></em>' containment reference list.
	 * The list contents are of type {@link diseaseinfo22.Doctors}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Doctors</em>' containment reference list.
	 * @see diseaseinfo22.Diseaseinfo22Package#getDiseasePredectionSystem_Doctors()
	 * @model containment="true"
	 * @generated
	 */
	EList<Doctors> getDoctors();

	/**
	 * Returns the value of the '<em><b>Healthreport</b></em>' containment reference list.
	 * The list contents are of type {@link diseaseinfo22.HealthReport}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Healthreport</em>' containment reference list.
	 * @see diseaseinfo22.Diseaseinfo22Package#getDiseasePredectionSystem_Healthreport()
	 * @model containment="true"
	 * @generated
	 */
	EList<HealthReport> getHealthreport();

	/**
	 * Returns the value of the '<em><b>Patients</b></em>' containment reference list.
	 * The list contents are of type {@link diseaseinfo22.Patients}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Patients</em>' containment reference list.
	 * @see diseaseinfo22.Diseaseinfo22Package#getDiseasePredectionSystem_Patients()
	 * @model containment="true"
	 * @generated
	 */
	EList<Patients> getPatients();

} // DiseasePredectionSystem
