/**
 */
package diseaseinfo22;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Patients</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link diseaseinfo22.Patients#getName <em>Name</em>}</li>
 *   <li>{@link diseaseinfo22.Patients#getType <em>Type</em>}</li>
 *   <li>{@link diseaseinfo22.Patients#getSymptoms <em>Symptoms</em>}</li>
 *   <li>{@link diseaseinfo22.Patients#getDisease <em>Disease</em>}</li>
 *   <li>{@link diseaseinfo22.Patients#getDoctors <em>Doctors</em>}</li>
 *   <li>{@link diseaseinfo22.Patients#getHealthreport <em>Healthreport</em>}</li>
 * </ul>
 *
 * @see diseaseinfo22.Diseaseinfo22Package#getPatients()
 * @model
 * @generated
 */
public interface Patients extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see diseaseinfo22.Diseaseinfo22Package#getPatients_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link diseaseinfo22.Patients#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see #setType(String)
	 * @see diseaseinfo22.Diseaseinfo22Package#getPatients_Type()
	 * @model
	 * @generated
	 */
	String getType();

	/**
	 * Sets the value of the '{@link diseaseinfo22.Patients#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see #getType()
	 * @generated
	 */
	void setType(String value);

	/**
	 * Returns the value of the '<em><b>Symptoms</b></em>' reference list.
	 * The list contents are of type {@link diseaseinfo22.Symptoms}.
	 * It is bidirectional and its opposite is '{@link diseaseinfo22.Symptoms#getPatients <em>Patients</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Symptoms</em>' reference list.
	 * @see diseaseinfo22.Diseaseinfo22Package#getPatients_Symptoms()
	 * @see diseaseinfo22.Symptoms#getPatients
	 * @model opposite="patients" required="true"
	 * @generated
	 */
	EList<Symptoms> getSymptoms();

	/**
	 * Returns the value of the '<em><b>Disease</b></em>' reference list.
	 * The list contents are of type {@link diseaseinfo22.Disease}.
	 * It is bidirectional and its opposite is '{@link diseaseinfo22.Disease#getPatients <em>Patients</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Disease</em>' reference list.
	 * @see diseaseinfo22.Diseaseinfo22Package#getPatients_Disease()
	 * @see diseaseinfo22.Disease#getPatients
	 * @model opposite="patients"
	 * @generated
	 */
	EList<Disease> getDisease();

	/**
	 * Returns the value of the '<em><b>Doctors</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link diseaseinfo22.Doctors#getPatients <em>Patients</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Doctors</em>' reference.
	 * @see #setDoctors(Doctors)
	 * @see diseaseinfo22.Diseaseinfo22Package#getPatients_Doctors()
	 * @see diseaseinfo22.Doctors#getPatients
	 * @model opposite="patients" required="true"
	 * @generated
	 */
	Doctors getDoctors();

	/**
	 * Sets the value of the '{@link diseaseinfo22.Patients#getDoctors <em>Doctors</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Doctors</em>' reference.
	 * @see #getDoctors()
	 * @generated
	 */
	void setDoctors(Doctors value);

	/**
	 * Returns the value of the '<em><b>Healthreport</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link diseaseinfo22.HealthReport#getPatients <em>Patients</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Healthreport</em>' reference.
	 * @see #setHealthreport(HealthReport)
	 * @see diseaseinfo22.Diseaseinfo22Package#getPatients_Healthreport()
	 * @see diseaseinfo22.HealthReport#getPatients
	 * @model opposite="patients" required="true"
	 * @generated
	 */
	HealthReport getHealthreport();

	/**
	 * Sets the value of the '{@link diseaseinfo22.Patients#getHealthreport <em>Healthreport</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Healthreport</em>' reference.
	 * @see #getHealthreport()
	 * @generated
	 */
	void setHealthreport(HealthReport value);

} // Patients
