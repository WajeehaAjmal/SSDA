/**
 */
package diseaseinfo22;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see diseaseinfo22.Diseaseinfo22Factory
 * @model kind="package"
 * @generated
 */
public interface Diseaseinfo22Package extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "diseaseinfo22";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/diseaseinfo22";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "diseaseinfo22";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	Diseaseinfo22Package eINSTANCE = diseaseinfo22.impl.Diseaseinfo22PackageImpl.init();

	/**
	 * The meta object id for the '{@link diseaseinfo22.impl.DiseasePredectionSystemImpl <em>Disease Predection System</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see diseaseinfo22.impl.DiseasePredectionSystemImpl
	 * @see diseaseinfo22.impl.Diseaseinfo22PackageImpl#getDiseasePredectionSystem()
	 * @generated
	 */
	int DISEASE_PREDECTION_SYSTEM = 0;

	/**
	 * The feature id for the '<em><b>Disease</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISEASE_PREDECTION_SYSTEM__DISEASE = 0;

	/**
	 * The feature id for the '<em><b>Symptoms</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISEASE_PREDECTION_SYSTEM__SYMPTOMS = 1;

	/**
	 * The feature id for the '<em><b>Patients</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISEASE_PREDECTION_SYSTEM__PATIENTS = 2;

	/**
	 * The feature id for the '<em><b>Healthreport</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISEASE_PREDECTION_SYSTEM__HEALTHREPORT = 3;

	/**
	 * The feature id for the '<em><b>Doctors</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISEASE_PREDECTION_SYSTEM__DOCTORS = 4;

	/**
	 * The number of structural features of the '<em>Disease Predection System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISEASE_PREDECTION_SYSTEM_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Disease Predection System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISEASE_PREDECTION_SYSTEM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link diseaseinfo22.impl.DiseaseImpl <em>Disease</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see diseaseinfo22.impl.DiseaseImpl
	 * @see diseaseinfo22.impl.Diseaseinfo22PackageImpl#getDisease()
	 * @generated
	 */
	int DISEASE = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISEASE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISEASE__TYPE = 1;

	/**
	 * The feature id for the '<em><b>Symptoms</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISEASE__SYMPTOMS = 2;

	/**
	 * The feature id for the '<em><b>Patients</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISEASE__PATIENTS = 3;

	/**
	 * The number of structural features of the '<em>Disease</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISEASE_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Disease</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISEASE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link diseaseinfo22.impl.SymptomsImpl <em>Symptoms</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see diseaseinfo22.impl.SymptomsImpl
	 * @see diseaseinfo22.impl.Diseaseinfo22PackageImpl#getSymptoms()
	 * @generated
	 */
	int SYMPTOMS = 2;

	/**
	 * The feature id for the '<em><b>Types</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYMPTOMS__TYPES = 0;

	/**
	 * The feature id for the '<em><b>Numberofsymp</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYMPTOMS__NUMBEROFSYMP = 1;

	/**
	 * The feature id for the '<em><b>Disease</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYMPTOMS__DISEASE = 2;

	/**
	 * The feature id for the '<em><b>Patients</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYMPTOMS__PATIENTS = 3;

	/**
	 * The number of structural features of the '<em>Symptoms</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYMPTOMS_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Symptoms</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYMPTOMS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link diseaseinfo22.impl.PatientsImpl <em>Patients</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see diseaseinfo22.impl.PatientsImpl
	 * @see diseaseinfo22.impl.Diseaseinfo22PackageImpl#getPatients()
	 * @generated
	 */
	int PATIENTS = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATIENTS__NAME = 0;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATIENTS__TYPE = 1;

	/**
	 * The feature id for the '<em><b>Symptoms</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATIENTS__SYMPTOMS = 2;

	/**
	 * The feature id for the '<em><b>Disease</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATIENTS__DISEASE = 3;

	/**
	 * The feature id for the '<em><b>Doctors</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATIENTS__DOCTORS = 4;

	/**
	 * The feature id for the '<em><b>Healthreport</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATIENTS__HEALTHREPORT = 5;

	/**
	 * The number of structural features of the '<em>Patients</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATIENTS_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>Patients</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATIENTS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link diseaseinfo22.impl.HealthReportImpl <em>Health Report</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see diseaseinfo22.impl.HealthReportImpl
	 * @see diseaseinfo22.impl.Diseaseinfo22PackageImpl#getHealthReport()
	 * @generated
	 */
	int HEALTH_REPORT = 4;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HEALTH_REPORT__TYPE = 0;

	/**
	 * The feature id for the '<em><b>Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HEALTH_REPORT__NUMBER = 1;

	/**
	 * The feature id for the '<em><b>Patients</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HEALTH_REPORT__PATIENTS = 2;

	/**
	 * The feature id for the '<em><b>Doctors</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HEALTH_REPORT__DOCTORS = 3;

	/**
	 * The number of structural features of the '<em>Health Report</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HEALTH_REPORT_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Health Report</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HEALTH_REPORT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link diseaseinfo22.impl.DoctorsImpl <em>Doctors</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see diseaseinfo22.impl.DoctorsImpl
	 * @see diseaseinfo22.impl.Diseaseinfo22PackageImpl#getDoctors()
	 * @generated
	 */
	int DOCTORS = 5;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCTORS__TYPE = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCTORS__NAME = 1;

	/**
	 * The feature id for the '<em><b>Patients</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCTORS__PATIENTS = 2;

	/**
	 * The feature id for the '<em><b>Healthreport</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCTORS__HEALTHREPORT = 3;

	/**
	 * The number of structural features of the '<em>Doctors</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCTORS_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Doctors</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCTORS_OPERATION_COUNT = 0;

	/**
	 * Returns the meta object for class '{@link diseaseinfo22.DiseasePredectionSystem <em>Disease Predection System</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Disease Predection System</em>'.
	 * @see diseaseinfo22.DiseasePredectionSystem
	 * @generated
	 */
	EClass getDiseasePredectionSystem();

	/**
	 * Returns the meta object for the containment reference list '{@link diseaseinfo22.DiseasePredectionSystem#getDisease <em>Disease</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Disease</em>'.
	 * @see diseaseinfo22.DiseasePredectionSystem#getDisease()
	 * @see #getDiseasePredectionSystem()
	 * @generated
	 */
	EReference getDiseasePredectionSystem_Disease();

	/**
	 * Returns the meta object for the containment reference list '{@link diseaseinfo22.DiseasePredectionSystem#getSymptoms <em>Symptoms</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Symptoms</em>'.
	 * @see diseaseinfo22.DiseasePredectionSystem#getSymptoms()
	 * @see #getDiseasePredectionSystem()
	 * @generated
	 */
	EReference getDiseasePredectionSystem_Symptoms();

	/**
	 * Returns the meta object for the containment reference list '{@link diseaseinfo22.DiseasePredectionSystem#getDoctors <em>Doctors</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Doctors</em>'.
	 * @see diseaseinfo22.DiseasePredectionSystem#getDoctors()
	 * @see #getDiseasePredectionSystem()
	 * @generated
	 */
	EReference getDiseasePredectionSystem_Doctors();

	/**
	 * Returns the meta object for the containment reference list '{@link diseaseinfo22.DiseasePredectionSystem#getHealthreport <em>Healthreport</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Healthreport</em>'.
	 * @see diseaseinfo22.DiseasePredectionSystem#getHealthreport()
	 * @see #getDiseasePredectionSystem()
	 * @generated
	 */
	EReference getDiseasePredectionSystem_Healthreport();

	/**
	 * Returns the meta object for the containment reference list '{@link diseaseinfo22.DiseasePredectionSystem#getPatients <em>Patients</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Patients</em>'.
	 * @see diseaseinfo22.DiseasePredectionSystem#getPatients()
	 * @see #getDiseasePredectionSystem()
	 * @generated
	 */
	EReference getDiseasePredectionSystem_Patients();

	/**
	 * Returns the meta object for class '{@link diseaseinfo22.Disease <em>Disease</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Disease</em>'.
	 * @see diseaseinfo22.Disease
	 * @generated
	 */
	EClass getDisease();

	/**
	 * Returns the meta object for the attribute '{@link diseaseinfo22.Disease#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see diseaseinfo22.Disease#getName()
	 * @see #getDisease()
	 * @generated
	 */
	EAttribute getDisease_Name();

	/**
	 * Returns the meta object for the attribute '{@link diseaseinfo22.Disease#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see diseaseinfo22.Disease#getType()
	 * @see #getDisease()
	 * @generated
	 */
	EAttribute getDisease_Type();

	/**
	 * Returns the meta object for the reference list '{@link diseaseinfo22.Disease#getSymptoms <em>Symptoms</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Symptoms</em>'.
	 * @see diseaseinfo22.Disease#getSymptoms()
	 * @see #getDisease()
	 * @generated
	 */
	EReference getDisease_Symptoms();

	/**
	 * Returns the meta object for the reference '{@link diseaseinfo22.Disease#getPatients <em>Patients</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Patients</em>'.
	 * @see diseaseinfo22.Disease#getPatients()
	 * @see #getDisease()
	 * @generated
	 */
	EReference getDisease_Patients();

	/**
	 * Returns the meta object for class '{@link diseaseinfo22.Symptoms <em>Symptoms</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Symptoms</em>'.
	 * @see diseaseinfo22.Symptoms
	 * @generated
	 */
	EClass getSymptoms();

	/**
	 * Returns the meta object for the attribute '{@link diseaseinfo22.Symptoms#getTypes <em>Types</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Types</em>'.
	 * @see diseaseinfo22.Symptoms#getTypes()
	 * @see #getSymptoms()
	 * @generated
	 */
	EAttribute getSymptoms_Types();

	/**
	 * Returns the meta object for the attribute '{@link diseaseinfo22.Symptoms#getNumberofsymp <em>Numberofsymp</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Numberofsymp</em>'.
	 * @see diseaseinfo22.Symptoms#getNumberofsymp()
	 * @see #getSymptoms()
	 * @generated
	 */
	EAttribute getSymptoms_Numberofsymp();

	/**
	 * Returns the meta object for the reference list '{@link diseaseinfo22.Symptoms#getDisease <em>Disease</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Disease</em>'.
	 * @see diseaseinfo22.Symptoms#getDisease()
	 * @see #getSymptoms()
	 * @generated
	 */
	EReference getSymptoms_Disease();

	/**
	 * Returns the meta object for the reference '{@link diseaseinfo22.Symptoms#getPatients <em>Patients</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Patients</em>'.
	 * @see diseaseinfo22.Symptoms#getPatients()
	 * @see #getSymptoms()
	 * @generated
	 */
	EReference getSymptoms_Patients();

	/**
	 * Returns the meta object for class '{@link diseaseinfo22.Patients <em>Patients</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Patients</em>'.
	 * @see diseaseinfo22.Patients
	 * @generated
	 */
	EClass getPatients();

	/**
	 * Returns the meta object for the attribute '{@link diseaseinfo22.Patients#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see diseaseinfo22.Patients#getName()
	 * @see #getPatients()
	 * @generated
	 */
	EAttribute getPatients_Name();

	/**
	 * Returns the meta object for the attribute '{@link diseaseinfo22.Patients#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see diseaseinfo22.Patients#getType()
	 * @see #getPatients()
	 * @generated
	 */
	EAttribute getPatients_Type();

	/**
	 * Returns the meta object for the reference list '{@link diseaseinfo22.Patients#getSymptoms <em>Symptoms</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Symptoms</em>'.
	 * @see diseaseinfo22.Patients#getSymptoms()
	 * @see #getPatients()
	 * @generated
	 */
	EReference getPatients_Symptoms();

	/**
	 * Returns the meta object for the reference list '{@link diseaseinfo22.Patients#getDisease <em>Disease</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Disease</em>'.
	 * @see diseaseinfo22.Patients#getDisease()
	 * @see #getPatients()
	 * @generated
	 */
	EReference getPatients_Disease();

	/**
	 * Returns the meta object for the reference '{@link diseaseinfo22.Patients#getDoctors <em>Doctors</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Doctors</em>'.
	 * @see diseaseinfo22.Patients#getDoctors()
	 * @see #getPatients()
	 * @generated
	 */
	EReference getPatients_Doctors();

	/**
	 * Returns the meta object for the reference '{@link diseaseinfo22.Patients#getHealthreport <em>Healthreport</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Healthreport</em>'.
	 * @see diseaseinfo22.Patients#getHealthreport()
	 * @see #getPatients()
	 * @generated
	 */
	EReference getPatients_Healthreport();

	/**
	 * Returns the meta object for class '{@link diseaseinfo22.HealthReport <em>Health Report</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Health Report</em>'.
	 * @see diseaseinfo22.HealthReport
	 * @generated
	 */
	EClass getHealthReport();

	/**
	 * Returns the meta object for the attribute '{@link diseaseinfo22.HealthReport#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see diseaseinfo22.HealthReport#getType()
	 * @see #getHealthReport()
	 * @generated
	 */
	EAttribute getHealthReport_Type();

	/**
	 * Returns the meta object for the attribute '{@link diseaseinfo22.HealthReport#getNumber <em>Number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Number</em>'.
	 * @see diseaseinfo22.HealthReport#getNumber()
	 * @see #getHealthReport()
	 * @generated
	 */
	EAttribute getHealthReport_Number();

	/**
	 * Returns the meta object for the reference '{@link diseaseinfo22.HealthReport#getPatients <em>Patients</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Patients</em>'.
	 * @see diseaseinfo22.HealthReport#getPatients()
	 * @see #getHealthReport()
	 * @generated
	 */
	EReference getHealthReport_Patients();

	/**
	 * Returns the meta object for the reference list '{@link diseaseinfo22.HealthReport#getDoctors <em>Doctors</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Doctors</em>'.
	 * @see diseaseinfo22.HealthReport#getDoctors()
	 * @see #getHealthReport()
	 * @generated
	 */
	EReference getHealthReport_Doctors();

	/**
	 * Returns the meta object for class '{@link diseaseinfo22.Doctors <em>Doctors</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Doctors</em>'.
	 * @see diseaseinfo22.Doctors
	 * @generated
	 */
	EClass getDoctors();

	/**
	 * Returns the meta object for the attribute '{@link diseaseinfo22.Doctors#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see diseaseinfo22.Doctors#getType()
	 * @see #getDoctors()
	 * @generated
	 */
	EAttribute getDoctors_Type();

	/**
	 * Returns the meta object for the attribute '{@link diseaseinfo22.Doctors#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see diseaseinfo22.Doctors#getName()
	 * @see #getDoctors()
	 * @generated
	 */
	EAttribute getDoctors_Name();

	/**
	 * Returns the meta object for the reference list '{@link diseaseinfo22.Doctors#getPatients <em>Patients</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Patients</em>'.
	 * @see diseaseinfo22.Doctors#getPatients()
	 * @see #getDoctors()
	 * @generated
	 */
	EReference getDoctors_Patients();

	/**
	 * Returns the meta object for the reference list '{@link diseaseinfo22.Doctors#getHealthreport <em>Healthreport</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Healthreport</em>'.
	 * @see diseaseinfo22.Doctors#getHealthreport()
	 * @see #getDoctors()
	 * @generated
	 */
	EReference getDoctors_Healthreport();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	Diseaseinfo22Factory getDiseaseinfo22Factory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link diseaseinfo22.impl.DiseasePredectionSystemImpl <em>Disease Predection System</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see diseaseinfo22.impl.DiseasePredectionSystemImpl
		 * @see diseaseinfo22.impl.Diseaseinfo22PackageImpl#getDiseasePredectionSystem()
		 * @generated
		 */
		EClass DISEASE_PREDECTION_SYSTEM = eINSTANCE.getDiseasePredectionSystem();

		/**
		 * The meta object literal for the '<em><b>Disease</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DISEASE_PREDECTION_SYSTEM__DISEASE = eINSTANCE.getDiseasePredectionSystem_Disease();

		/**
		 * The meta object literal for the '<em><b>Symptoms</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DISEASE_PREDECTION_SYSTEM__SYMPTOMS = eINSTANCE.getDiseasePredectionSystem_Symptoms();

		/**
		 * The meta object literal for the '<em><b>Doctors</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DISEASE_PREDECTION_SYSTEM__DOCTORS = eINSTANCE.getDiseasePredectionSystem_Doctors();

		/**
		 * The meta object literal for the '<em><b>Healthreport</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DISEASE_PREDECTION_SYSTEM__HEALTHREPORT = eINSTANCE.getDiseasePredectionSystem_Healthreport();

		/**
		 * The meta object literal for the '<em><b>Patients</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DISEASE_PREDECTION_SYSTEM__PATIENTS = eINSTANCE.getDiseasePredectionSystem_Patients();

		/**
		 * The meta object literal for the '{@link diseaseinfo22.impl.DiseaseImpl <em>Disease</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see diseaseinfo22.impl.DiseaseImpl
		 * @see diseaseinfo22.impl.Diseaseinfo22PackageImpl#getDisease()
		 * @generated
		 */
		EClass DISEASE = eINSTANCE.getDisease();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DISEASE__NAME = eINSTANCE.getDisease_Name();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DISEASE__TYPE = eINSTANCE.getDisease_Type();

		/**
		 * The meta object literal for the '<em><b>Symptoms</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DISEASE__SYMPTOMS = eINSTANCE.getDisease_Symptoms();

		/**
		 * The meta object literal for the '<em><b>Patients</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DISEASE__PATIENTS = eINSTANCE.getDisease_Patients();

		/**
		 * The meta object literal for the '{@link diseaseinfo22.impl.SymptomsImpl <em>Symptoms</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see diseaseinfo22.impl.SymptomsImpl
		 * @see diseaseinfo22.impl.Diseaseinfo22PackageImpl#getSymptoms()
		 * @generated
		 */
		EClass SYMPTOMS = eINSTANCE.getSymptoms();

		/**
		 * The meta object literal for the '<em><b>Types</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SYMPTOMS__TYPES = eINSTANCE.getSymptoms_Types();

		/**
		 * The meta object literal for the '<em><b>Numberofsymp</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SYMPTOMS__NUMBEROFSYMP = eINSTANCE.getSymptoms_Numberofsymp();

		/**
		 * The meta object literal for the '<em><b>Disease</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SYMPTOMS__DISEASE = eINSTANCE.getSymptoms_Disease();

		/**
		 * The meta object literal for the '<em><b>Patients</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SYMPTOMS__PATIENTS = eINSTANCE.getSymptoms_Patients();

		/**
		 * The meta object literal for the '{@link diseaseinfo22.impl.PatientsImpl <em>Patients</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see diseaseinfo22.impl.PatientsImpl
		 * @see diseaseinfo22.impl.Diseaseinfo22PackageImpl#getPatients()
		 * @generated
		 */
		EClass PATIENTS = eINSTANCE.getPatients();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PATIENTS__NAME = eINSTANCE.getPatients_Name();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PATIENTS__TYPE = eINSTANCE.getPatients_Type();

		/**
		 * The meta object literal for the '<em><b>Symptoms</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PATIENTS__SYMPTOMS = eINSTANCE.getPatients_Symptoms();

		/**
		 * The meta object literal for the '<em><b>Disease</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PATIENTS__DISEASE = eINSTANCE.getPatients_Disease();

		/**
		 * The meta object literal for the '<em><b>Doctors</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PATIENTS__DOCTORS = eINSTANCE.getPatients_Doctors();

		/**
		 * The meta object literal for the '<em><b>Healthreport</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PATIENTS__HEALTHREPORT = eINSTANCE.getPatients_Healthreport();

		/**
		 * The meta object literal for the '{@link diseaseinfo22.impl.HealthReportImpl <em>Health Report</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see diseaseinfo22.impl.HealthReportImpl
		 * @see diseaseinfo22.impl.Diseaseinfo22PackageImpl#getHealthReport()
		 * @generated
		 */
		EClass HEALTH_REPORT = eINSTANCE.getHealthReport();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HEALTH_REPORT__TYPE = eINSTANCE.getHealthReport_Type();

		/**
		 * The meta object literal for the '<em><b>Number</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HEALTH_REPORT__NUMBER = eINSTANCE.getHealthReport_Number();

		/**
		 * The meta object literal for the '<em><b>Patients</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HEALTH_REPORT__PATIENTS = eINSTANCE.getHealthReport_Patients();

		/**
		 * The meta object literal for the '<em><b>Doctors</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HEALTH_REPORT__DOCTORS = eINSTANCE.getHealthReport_Doctors();

		/**
		 * The meta object literal for the '{@link diseaseinfo22.impl.DoctorsImpl <em>Doctors</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see diseaseinfo22.impl.DoctorsImpl
		 * @see diseaseinfo22.impl.Diseaseinfo22PackageImpl#getDoctors()
		 * @generated
		 */
		EClass DOCTORS = eINSTANCE.getDoctors();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOCTORS__TYPE = eINSTANCE.getDoctors_Type();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOCTORS__NAME = eINSTANCE.getDoctors_Name();

		/**
		 * The meta object literal for the '<em><b>Patients</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCTORS__PATIENTS = eINSTANCE.getDoctors_Patients();

		/**
		 * The meta object literal for the '<em><b>Healthreport</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCTORS__HEALTHREPORT = eINSTANCE.getDoctors_Healthreport();

	}

} //Diseaseinfo22Package
