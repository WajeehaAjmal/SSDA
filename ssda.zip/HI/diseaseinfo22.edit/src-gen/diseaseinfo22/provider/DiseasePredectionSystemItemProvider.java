/**
 */
package diseaseinfo22.provider;

import diseaseinfo22.DiseasePredectionSystem;
import diseaseinfo22.Diseaseinfo22Factory;
import diseaseinfo22.Diseaseinfo22Package;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.edit.provider.IEditingDomainItemProvider;
import org.eclipse.emf.edit.provider.IItemLabelProvider;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.IItemPropertySource;
import org.eclipse.emf.edit.provider.IStructuredItemContentProvider;
import org.eclipse.emf.edit.provider.ITreeItemContentProvider;
import org.eclipse.emf.edit.provider.ItemProviderAdapter;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link diseaseinfo22.DiseasePredectionSystem} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class DiseasePredectionSystemItemProvider extends ItemProviderAdapter implements IEditingDomainItemProvider,
		IStructuredItemContentProvider, ITreeItemContentProvider, IItemLabelProvider, IItemPropertySource {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DiseasePredectionSystemItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

		}
		return itemPropertyDescriptors;
	}

	/**
	 * This specifies how to implement {@link #getChildren} and is used to deduce an appropriate feature for an
	 * {@link org.eclipse.emf.edit.command.AddCommand}, {@link org.eclipse.emf.edit.command.RemoveCommand} or
	 * {@link org.eclipse.emf.edit.command.MoveCommand} in {@link #createCommand}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Collection<? extends EStructuralFeature> getChildrenFeatures(Object object) {
		if (childrenFeatures == null) {
			super.getChildrenFeatures(object);
			childrenFeatures.add(Diseaseinfo22Package.Literals.DISEASE_PREDECTION_SYSTEM__DISEASE);
			childrenFeatures.add(Diseaseinfo22Package.Literals.DISEASE_PREDECTION_SYSTEM__SYMPTOMS);
			childrenFeatures.add(Diseaseinfo22Package.Literals.DISEASE_PREDECTION_SYSTEM__PATIENTS);
			childrenFeatures.add(Diseaseinfo22Package.Literals.DISEASE_PREDECTION_SYSTEM__HEALTHREPORT);
			childrenFeatures.add(Diseaseinfo22Package.Literals.DISEASE_PREDECTION_SYSTEM__DOCTORS);
		}
		return childrenFeatures;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EStructuralFeature getChildFeature(Object object, Object child) {
		// Check the type of the specified child object and return the proper feature to use for
		// adding (see {@link AddCommand}) it as a child.

		return super.getChildFeature(object, child);
	}

	/**
	 * This returns DiseasePredectionSystem.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/DiseasePredectionSystem"));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean shouldComposeCreationImage() {
		return true;
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		return getString("_UI_DiseasePredectionSystem_type");
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(DiseasePredectionSystem.class)) {
		case Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__DISEASE:
		case Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__SYMPTOMS:
		case Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__PATIENTS:
		case Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__HEALTHREPORT:
		case Diseaseinfo22Package.DISEASE_PREDECTION_SYSTEM__DOCTORS:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), true, false));
			return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);

		newChildDescriptors.add(createChildParameter(Diseaseinfo22Package.Literals.DISEASE_PREDECTION_SYSTEM__DISEASE,
				Diseaseinfo22Factory.eINSTANCE.createDisease()));

		newChildDescriptors.add(createChildParameter(Diseaseinfo22Package.Literals.DISEASE_PREDECTION_SYSTEM__SYMPTOMS,
				Diseaseinfo22Factory.eINSTANCE.createSymptoms()));

		newChildDescriptors.add(createChildParameter(Diseaseinfo22Package.Literals.DISEASE_PREDECTION_SYSTEM__PATIENTS,
				Diseaseinfo22Factory.eINSTANCE.createPatients()));

		newChildDescriptors
				.add(createChildParameter(Diseaseinfo22Package.Literals.DISEASE_PREDECTION_SYSTEM__HEALTHREPORT,
						Diseaseinfo22Factory.eINSTANCE.createHealthReport()));

		newChildDescriptors.add(createChildParameter(Diseaseinfo22Package.Literals.DISEASE_PREDECTION_SYSTEM__DOCTORS,
				Diseaseinfo22Factory.eINSTANCE.createDoctors()));
	}

	/**
	 * Return the resource locator for this item provider's resources.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		return Diseaseinfo22EditPlugin.INSTANCE;
	}

}
